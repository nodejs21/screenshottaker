import { Component, OnInit } from '@angular/core';
import { Person } from '../../models/person';
import { RoomsService } from '../../services/rooms.service';
import { ElectronService } from 'ngx-electron';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from 'angularfire2/firestore';
import { FirebaseApp } from 'angularfire2';
import { Observable, Notification } from 'rxjs';
import { NEXT } from '@angular/core/src/render3/interfaces/view';
import { FsService } from 'ngx-fs';
import { AngularFireStorage, AngularFireUploadTask } from 'angularfire2/storage';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  
  message;
  person: Person;
  presenterCollection: AngularFirestoreCollection<Person>;
  tempPresentor: AngularFirestoreDocument<any>;
  presenter: Observable<any>;
  audience: Observable<Person[]>;
  presenterId;
  audienceId;
  isAudience = false;
  isPresenter = false;
  
  captureFlag = false;
  
  valid: boolean = false;
  canCapture: boolean = true;
  
  task: AngularFireUploadTask;
  
  
  constructor(
    private http: HttpClient,
    public roomService: RoomsService,
    public _electronService: ElectronService,
    public _fsService: FsService,
    public afs: AngularFirestore,
    public fbApp: FirebaseApp,
    public storage: AngularFireStorage
  ) {
    this.person = {
      type: "Presenter",
      roomName: null,
      token: null
    };
    // Listen for service successfully started
    this._electronService.ipcRenderer.on('PUSH_RECEIVER:::NOTIFICATION_SERVICE_STARTED', (_, token) => {
      console.log('service successfully started', token)
      this.person.token = token;
    })
    // Handle notification errors
    this._electronService.ipcRenderer.on('PUSH_RECEIVER:::NOTIFICATION_SERVICE_ERROR', (_, error) => {
      console.log('notification error', error)
    })
    // Send FCM token to backend
    this._electronService.ipcRenderer.on('PUSH_RECEIVER:::TOKEN_UPDATED', (_, token) => {
      console.log('token updated', token)
    })
    // Start service
    const senderId = '585811144945' // <-- replace with FCM sender ID from FCM web admin under Settings->Cloud Messaging
    console.log('starting service and registering a client')
    this._electronService.ipcRenderer.send('PUSH_RECEIVER:::START_NOTIFICATION_SERVICE', senderId);
  }
  
  ngOnInit() {
    try {
      // this.roomService.getPresenters().subscribe(persons => {
      //   console.log(persons);
      // })
      
      // Display notification
      this._electronService.ipcRenderer.on('PUSH_RECEIVER:::NOTIFICATION_RECEIVED', (_, serverNotificationPayload) => {
        // check to see if payload contains a body string, if it doesn't consider it a silent push
        if (serverNotificationPayload.notification.body){
          // payload has a body, so show it to the user
          console.log('display notification', serverNotificationPayload)
          let myNotification = new Notification(serverNotificationPayload.notification.title, {
            body: serverNotificationPayload.notification.body
          })
          
          // myNotification.onclick = () => {
          //   console.log('Notification clicked')
          // }  
          
        } else {
          // payload has no body, so consider it silent (and just consider the data portion)
          console.log('do something with the key/value pairs in the data', serverNotificationPayload.data)
        }
      })
      
      {
        // console.log(typeof this.person);
        // console.log('Here i go...');
        // this.msgService.getPermission()
        // this.msgService.receiveMessage()
        // this.message = this.msgService.currentMessage;
        
        // console.log(this.message);
        // const messaging = firebase.messaging();
        // messaging.requestPermission()
        // .then(() => {
        //   console.log('Have permission..');
        // })
        // .then((token) => {
        //   console.log(token);
        // })
        // .catch((err) => {
        //   console.log(err);
        // })   
      }
    } catch (error) {
      console.log(error);
    }
    
    
  }
  
  submitForm(form) {
    if(form.valid) {
      this.person.type = form.value.type;
      this.person.roomName = form.value.roomName;
      if(this.person.type == "Presenter") {
        
        {
          //   var flag = true;
          //   this.presenterCollection.snapshotChanges()
          //   .subscribe(snapshot => {
          //     if(snapshot.length == 0) {
          //       flag = false;
          //       this.afs.collection('presenters').add(this.person)
          //       .then(result => {
          //         // this._electronService.ipcRenderer.send('notify', {'title': "Update", "body": "New room created"});
          //         alert("New room created");
          //         console.log("New room created");
          //       })
          //       .catch(err => {
          //         console.log(err);                
          //       });
          //     } else if(flag){
          //       console.log("This room already exists");
          //       // this._electronService.ipcRenderer.send('notify', {'title': "Update", "body": "This room already exists"});
          //       alert("This room already exists");
          //     }
          //   })
          // } catch (error) {
          //   console.log(error);
          // }
        }
        this.valid = true;
        this.roomService.addPresenter(this.person)
        .then(person => {
          // console.log(person);
          this.presenterId = person["id"];
          alert(`Room: '${this.person.roomName}' created!`);
          form.reset();
          // this.roomService.listenAudience()
          this.presenterId = person["id"];
          this.isPresenter = true;
          this.roomService.listenAudience()
          .subscribe(change => {
            console.log(change);
            console.log(change.length);
            if(change.length !== 0) {
              // console.log(change);
              this.capture(this.person.token);
              // this._electronService.ipcRenderer.send("captureScreen", 2);
            }
          })
          // alert("Room successfully created!");
        })
        .catch(err => {
          console.log(err);
          this.valid = false;
          alert(err);
        });
      } else if (this.person.type == "Audience") {
        this.roomService.addAudience(this.person)
        .then(result => {
          alert(`Room:'${this.person.roomName}' joined`);
          this.audienceId = result["id"];
          form.reset();
          // this.roomService.listenPresenter()
          this.isAudience = true;
          this.roomService.listenPresenter()
          .subscribe(uploaded => {
            console.log(uploaded);
            if(uploaded.length == 0){
              this.isAudience = false;
              this.leaveRoom(false);
              alert("Presenter has deleted the room!");
            } else {
              console.log(uploaded);
              console.log(uploaded[0]["payload"]["doc"]["id"]);
              console.log(uploaded.length);
              let url;
              url = uploaded["0"].payload.doc._document.data.internalValue.root.value.internalValue;
              // console.log(url.substr(0, 5) == "https");
              if(url.substr(0, 5) == "https") {
                this._electronService.ipcRenderer.send("downloadImage", {
                  url,
                  properties: {directory: "Directory is here"}
                });
                this.canCapture = true;
                alert("Screenshot saved in downloads folder!");
              }
            }
          })
        })
        .catch(err => {
          console.log(err);
          this.valid = false;
          alert(`Room:'${this.person.roomName}' not found`);
        })
      }
    }
  }
  
  capture(updated) {
    // console.log(updated);
    this.canCapture = false;
    const thumbSize = this._electronService.screen.getPrimaryDisplay().size;
    let options = {types: ['screen'], thumbnailSize: thumbSize};
    console.log(thumbSize);
    
    this._electronService.desktopCapturer.getSources(options, (err, sources) => {
      if(err) {
        console.log(err);
        console.log(err.message);
        return;
      }
      console.log(sources);
      sources.forEach((source) => {
        if(source.name === "Entire screen" || source.name === "Screen 1") {
          // .join(os.tmpdir(), 'screenshot.png');
          // const screenshotPath = path.join(os.tmpdir(), 'screenshot.png');
          var path = `screenshot/${this.person.token}_${new Date().getTime()}_screenshot.png`
          // console.log(options);
          
          // console.log(source);
          // console.log(source.thumbnail);
          // console.log(source.thumbnail.toPNG());
          
          this.task = this.storage.upload(path, source.thumbnail.toPNG());
          this.task.then(task => {
            console.log(task);
            task.ref.getDownloadURL()
            .then(url => {
              console.log(url);
              this.roomService.updateImageUrl({presenterId: this.presenterId, url})
              .then(success => {
                console.log(success);
              })
              .catch(err => {
                console.log(err);
              })
            })
            .catch(err => {
              console.log(err);
            })
            // console.log(url.task.then(j => console.log(j.downloadURL)));
          })
          .catch(err => {
            console.log(err);
          });
          
          // fs.writeFile(screenshotPath, source.thumbnail.toPNG(), function(err) {
          //   if(err) return console.log(err);
          //   var message = "Saved screenshot to: " + screenshotPath;
          // })
        }
      })
    })
    // desktopCapturer.getSources(options, function(err, sources) {
    //   if(err) {
    //     console.log(err);
    //     console.log(err.message);
    //     return;
    //   }
    //   sources.forEach(function(source) {
    //     if(source.name === "Entire Screen" || source.name === "Screen 1") {
    //       const screenshotPath = path.join(os.tmpdir(), 'screenshot.png');
    //       fs.writeFile(screenshotPath, source.thumbnail.toPNG(), function(err) {
    //         if(err) return console.log(err);
    //         var message = "Saved screenshot to: " + screenshotPath;
    //       })
    //     }
    //   })
    //     // this._electronService.ipcRenderer.sendSync("captureScreen", 2);
  }
  
  closeRoom() {
    this.roomService.remove('presenters', this.presenterId)
    .then(result => {
      alert("Room deleted!");
      this.isPresenter = false;
      this.valid = false;
      this.ngOnInit();
    })
    .catch(err => {
      console.log(err);
    })
  }
  
  leaveRoom(show?) {
    this.roomService.remove('audience', this.audienceId)
    .then(result => {
      this.valid = false;
      if(show) {
        alert("Room left.");
      }
      // alert("Your session is broken!\nTry to reconnect.");
      // console.log(this.audienceId);
      this.isAudience = false;
      this.ngOnInit();
    })
    .catch(err => {
      console.log(err);
    })
  }
  
  captureScreen() {
    console.log("Going to capture screen...");
    this.roomService.updateAudience(this.audienceId);
    // this._electronService.ipcRenderer.on('captureScreen')
  }
  
}
