// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { PresenterComponent } from './components/presenter/presenter.component';
// import { AudienceComponent } from './components/audience/audience.component';

// const routes: Routes = [
//     {path: 'presnter', component: PresenterComponent},
//     {path: 'audience', component: AudienceComponent}
// ];

// @NgModule({
//     imports: [RouterModule.forRoot(routes, { useHash: true })],
//     exports: [RouterModule]
// })
// export class AppRoutingModule {}
// export const routingComponents  = [PresenterComponent, AudienceComponent]
