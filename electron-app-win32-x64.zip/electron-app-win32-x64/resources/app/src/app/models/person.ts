
export interface Person {
  type?: string;
  roomName?: string;
  token?: string;
  screenshotUrl?: string;
}